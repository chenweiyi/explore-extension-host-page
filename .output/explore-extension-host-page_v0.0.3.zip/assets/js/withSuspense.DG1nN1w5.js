import{j as s,r as t}from"./uno.yJt0TuE5.js";function o(e,n=null){return function(r){return s.jsx(t.Suspense,{fallback:n,children:s.jsx(e,{...r})})}}export{o as w};
