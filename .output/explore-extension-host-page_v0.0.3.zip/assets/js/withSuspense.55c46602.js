import{j as e,r as t}from"./uno.b2362ca2.js";function i(n,r=null){return function(s){return e(t.exports.Suspense,{fallback:r,children:e(n,{...s})})}}export{i as w};
